package com.scientiamobile.wurfl.core.matchers;

import com.scientiamobile.wurfl.core.request.WURFLRequest;

final class aa extends a {
  public final boolean canHandle(WURFLRequest paramWURFLRequest) {
    return (!paramWURFLRequest._internalIsDesktopBrowser() && paramWURFLRequest.getCleanedDeviceUserAgent().startsWith("Panasonic"));
  }
  
  public final String getMatcherName() {
    return "PanasonicMatcher";
  }
  
  public final String getBucketMatcherName() {
    return "Panasonic";
  }
}


/* Location:              D:\workspace\houkunlin\wurfl-jdk17\libs\wurfl-1.9.0.0.jar!\com\scientiamobile\wurfl\core\matchers\aa.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */