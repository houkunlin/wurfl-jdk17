package com.scientiamobile.wurfl.core.matchers;

import com.scientiamobile.wurfl.core.request.WURFLRequest;

final class ab extends a {
  public final boolean canHandle(WURFLRequest paramWURFLRequest) {
    return (!paramWURFLRequest._internalIsDesktopBrowser() && paramWURFLRequest.getCleanedDeviceUserAgent().startsWith("Qtek"));
  }
  
  public final String getMatcherName() {
    return "QtekMatcher";
  }
  
  public final String getBucketMatcherName() {
    return "Qtek";
  }
}


/* Location:              D:\workspace\houkunlin\wurfl-jdk17\libs\wurfl-1.9.0.0.jar!\com\scientiamobile\wurfl\core\matchers\ab.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */